package cms.cse.finalyear.project.mobimoni;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.location.Geofence.Builder;
import com.google.android.gms.location.LocationClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.makemyandroidapp.googleformuploader.GoogleFormUploader;
import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v4.app.FragmentActivity;
import android.telephony.SmsManager;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class Map extends FragmentActivity implements
 GooglePlayServicesClient.ConnectionCallbacks, GooglePlayServicesClient.OnConnectionFailedListener, LocationListener{
	
	AlertDialogManager alert = new AlertDialogManager();
	private static final int GPS_ERRORDIALOG_REQUEST = 9001;
	//  private static final double CHENNAI_LAT = 11.2550967;
	  private static final double CHENNAI_LAT = 11.3774987;
	  // private static final double CHENNAI_LOG = 78.1110523;
	  private static final double CHENNAI_LOG = 76.7484437;
	private static final float DEFAULTZOOM = 12;
	GoogleMap mMap;
	LocationClient mLocationClient;
	Circle c1;
	Marker marker;
	static String possibleEmail="";
	LatLng ll = new LatLng(CHENNAI_LAT, CHENNAI_LOG);
	Builder fence;
	String result = null;
   	InputStream is = null;
	StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
	String result1 = null;
   	InputStream is1 = null;
	StrictMode.ThreadPolicy policy1 = new StrictMode.ThreadPolicy.Builder().permitAll().build();
    public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		try{
            Account[] accounts = AccountManager.get(this).getAccountsByType("com.google");
            for (Account account : accounts) {
            possibleEmail = account.name;
            }
		}
       catch(Exception e)
       {
            Log.i("Exception", "Exception:"+e) ; 
       }
		if (servicesOk()) {
			setContentView(R.layout.activity_map);
			if (initMap()) {
					gotoLocation(CHENNAI_LAT, CHENNAI_LOG, DEFAULTZOOM);
					mLocationClient = new LocationClient(this,this,this);
					mLocationClient.connect();
					c1 = drawCircle(ll);
			}
			else{
					Toast.makeText(this , "Map Not Available!", Toast.LENGTH_SHORT).show();
			}
		}
		else {
				setContentView(R.layout.activity_mmain);
		}
	}
	private Circle drawCircle(LatLng ll) {
		CircleOptions opt = new CircleOptions().center(ll).radius(100000)
				.fillColor(0x330000FF).strokeColor(Color.BLUE).strokeWidth(3);
		return mMap.addCircle(opt);
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}
	
	public boolean servicesOk(){
		int isAvailable = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
		if (isAvailable == ConnectionResult.SUCCESS) {
			return true;
		}
		else if (GooglePlayServicesUtil.isUserRecoverableError(isAvailable)) {
			Dialog dialog = GooglePlayServicesUtil.getErrorDialog(isAvailable,this,GPS_ERRORDIALOG_REQUEST);
			dialog.show();
		} 
		else{
			Toast.makeText(this , "Can't connect to Google Play Services", Toast.LENGTH_SHORT).show();
		}
		return false;
	}
	private boolean initMap(){
		if (mMap == null) {
			SupportMapFragment mapFrag = 
					(SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
			mMap = mapFrag.getMap();
		}
		return (mMap != null);
	}
	private void gotoLocation(double lat, double lon, float zoom){
		LatLng ll = new LatLng(lat, lon);
		CameraUpdate update = CameraUpdateFactory.newLatLngZoom(ll, zoom);
		mMap.moveCamera(update);
	}
		@Override
	public boolean onOptionsItemSelected(MenuItem item) {
			
			switch (item.getItemId()) {
			case R.id.Register:
				Intent intent = new Intent(this, RegisterActivity.class);
				startActivity(intent);
				break;
			case R.id.MapView:
				
				break;
			case R.id.Notification:
				 Intent intent1 = new Intent(this, MainActivity.class);
				 startActivity(intent1);
				break;
			case R.id.currentlocation:
				gotoCurrentLocation();
				break;

			default:
				break;
			}
			return super.onOptionsItemSelected(item);		
	}
		@Override
	protected void onStop() {
			
			super.onStop();
			MapStateManager mgr = new MapStateManager(this);
			mgr.saveMapSate(mMap);
	}
		@Override
	protected void onResume() {
			
			super.onResume();
			MapStateManager mgr = new MapStateManager(this);
			CameraPosition position = mgr.getSavedCameraPosition();
			if (position!=null) {
				CameraUpdate update = CameraUpdateFactory.newCameraPosition(position);
				mMap.moveCamera(update);
			}
	}
	protected void gotoCurrentLocation(){
			Location currentLocation = mLocationClient.getLastLocation();
			if (currentLocation == null) {
				Toast.makeText(this , "Current location isn't available!", Toast.LENGTH_SHORT).show();
			}
			else {
				double a = currentLocation.getLatitude();
				double b = currentLocation.getLongitude();
				LatLng ll1 = new LatLng(a, b);
				CameraUpdate update = CameraUpdateFactory.newLatLngZoom(ll1, DEFAULTZOOM);
				mMap.animateCamera(update);
				// Toast.makeText(this , "mail :"+possibleEmail+"Current location is: "+a+" "+b+".", Toast.LENGTH_SHORT).show();
			}
	}
	@Override
	public void onConnectionFailed(ConnectionResult arg0) {
	}
		@Override
	public void onConnected(Bundle arg0) {
			
			Toast.makeText(this , "Connected to location services!", Toast.LENGTH_SHORT).show();
			LocationRequest request= LocationRequest.create();
			request.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
			request.setInterval(40000);
			request.setFastestInterval(1000);
			mLocationClient.requestLocationUpdates(request, this);
	}
		@Override
	public void onDisconnected() {
			
	}
		@Override
	public void onLocationChanged(Location location) {
			
			double ln=location.getLatitude();
			double lg= location.getLongitude();
			String a = Double.toString(ln);
			String b = Double.toString(lg);
			String date = (DateFormat.format("dd MMMM yyyy, hh:mm:ss ", new java.util.Date()).toString());
			float dist = getDistance(CHENNAI_LAT, CHENNAI_LOG, ln, lg);
			String msg = date +" Distance travelled: "+dist+" meters";
			Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
			String d = Float.toString(dist);
			String d1 = d+" m";
				ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
				nameValuePairs.add(new BasicNameValuePair("f1",possibleEmail));
        	   	nameValuePairs.add(new BasicNameValuePair("f2",a));
        	   	nameValuePairs.add(new BasicNameValuePair("f3",b));
        	   	nameValuePairs.add(new BasicNameValuePair("f4",date));
        	    nameValuePairs.add(new BasicNameValuePair("f5",d1));
        	   	StrictMode.setThreadPolicy(policy);
        	   	try{
        	        HttpClient httpclient = new DefaultHttpClient();
        	        HttpPost httppost = new HttpPost("http://www.arunk.yzi.me/insert1.php");
        	        httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
        	        HttpResponse response = httpclient.execute(httppost); 
        	        HttpEntity entity = response.getEntity();
        	        is = entity.getContent();
        	        Log.e("log_tag", "connection success ");
        	        Toast.makeText(getApplicationContext(), "pass", Toast.LENGTH_SHORT).show();
        	   	}
        	   	catch(Exception e)
        	   	{
        	        Log.e("log_tag", "Error in http connection "+e.toString());
        	        Toast.makeText(getApplicationContext(), "Connection fail", Toast.LENGTH_SHORT).show();
        	    }
        	   	try{
        	        BufferedReader reader = new BufferedReader(new InputStreamReader(is,"iso-8859-1"),8);
        	        StringBuilder sb = new StringBuilder();
        	        String line = null;
        	        while ((line = reader.readLine()) != null) 
        	        {
        	                sb.append(line + "\n");
        	        }
        	        is.close();
        	        result=sb.toString();
        	   	}
        	   	catch(Exception e)
        	   	{
        	       Log.e("log_tag", "Error converting result "+e.toString());
        	   	}
        	   	try{
	        		
					JSONObject json_data = new JSONObject(result);
	                CharSequence w= (CharSequence) json_data.get("re");	              
	                Toast.makeText(getApplicationContext(), w, Toast.LENGTH_SHORT).show();
        	   	}
        	   	catch(JSONException e)
        	   	{
        	   		Log.e("log_tag", "Error parsing data "+e.toString());
        	   		Toast.makeText(getApplicationContext(), "JsonArray fail", Toast.LENGTH_SHORT).show();
        	   	}
				GoogleFormUploader uploader = new GoogleFormUploader("1xgiLsc97xRgDoACEMrw2bFYmitousE48pJksMtLYvhw");
				uploader.addEntry("1165797493", possibleEmail);
				uploader.addEntry("1608398615", a);
				uploader.addEntry("988813058", b);
				uploader.addEntry("1521031460", d);
				// uploader.addEntry("1299421719", country);
				uploader.upload();
			    // CameraUpdate update = CameraUpdateFactory.newLatLngZoom(ll, DEFAULTZOOM);
			    // mMap.animateCamera(update);
			    if (marker != null) {
			    	marker.remove();
			    }	
			    MarkerOptions options = new MarkerOptions()
					.title("You are Here!").position(new LatLng(ln,lg));
			    marker = mMap.addMarker(options);
				if(dist>100000)
				{
					float cd = dist - 100000;
					String cds = Float.toString(cd);
					alert.showAlertDialog(Map.this,
						"Warning: Limit Exceeded",
						"You have croseed your limit of roaming. Please return back. You have exceeded :"+cds+" KM." , false);
					try {
						SmsManager smsManager = SmsManager.getDefault();
						// smsManager.sendTextMessage("+919500285331", null, "User : "+possibleEmail+" : Has crossed the boundary limit. Limit exceeded is :"+cds+" KM.", null, null);
						// Toast.makeText(getApplicationContext(), "SMS Sent.", Toast.LENGTH_SHORT).show();
					} 
					catch (Exception e) {
						
						e.printStackTrace();
						Toast.makeText(getApplicationContext(), "SMS Not Sent.", Toast.LENGTH_SHORT).show();
					}
					/*ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
					nameValuePairs.add(new BasicNameValuePair("f1",possibleEmail));
	        	   	nameValuePairs.add(new BasicNameValuePair("f2",a));
	        	   	nameValuePairs.add(new BasicNameValuePair("f3",b));
	        	   	nameValuePairs.add(new BasicNameValuePair("f4",date));
	        	    nameValuePairs.add(new BasicNameValuePair("f5",d1));
	        	   	StrictMode.setThreadPolicy(policy);*/
	        	   	try{
	        	        HttpClient httpclient = new DefaultHttpClient();
	        	        HttpPost httppost = new HttpPost("http://www.arunk.yzi.me/insert2.php");
	        	        httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
	        	        HttpResponse response = httpclient.execute(httppost); 
	        	        HttpEntity entity = response.getEntity();
	        	        is = entity.getContent();
	        	        Log.e("log_tag", "connection success ");
	        	        Toast.makeText(getApplicationContext(), "pass2", Toast.LENGTH_SHORT).show();
	        	   	}
	        	   	catch(Exception e)
	        	   	{
	        	        Log.e("log_tag", "Error in http connection "+e.toString());
	        	        Toast.makeText(getApplicationContext(), "Connection fail", Toast.LENGTH_SHORT).show();
	        	    }
	        	   	try{
	        	        BufferedReader reader = new BufferedReader(new InputStreamReader(is,"iso-8859-1"),8);
	        	        StringBuilder sb = new StringBuilder();
	        	        String line = null;
	        	        while ((line = reader.readLine()) != null) 
	        	        {
	        	                sb.append(line + "\n");
	        	        }
	        	        is.close();
	        	        result=sb.toString();
	        	   	}
	        	   	catch(Exception e)
	        	   	{
	        	       Log.e("log_tag", "Error converting result "+e.toString());
	        	   	}
	        	   	try{
		        		
						JSONObject json_data = new JSONObject(result);
		                CharSequence w= (CharSequence) json_data.get("re");	              
		                Toast.makeText(getApplicationContext(), w, Toast.LENGTH_SHORT).show();
	        	   	}
	        	   	catch(JSONException e)
	        	   	{
	        	   		Log.e("log_tag", "Error parsing data "+e.toString());
	        	   		Toast.makeText(getApplicationContext(), "JsonArray fail", Toast.LENGTH_SHORT).show();
	        	   	}
			}
			
	}
	public static float getDistance(double startLati, double startLongi, double goalLati, double goalLongi){
		    float[] resultArray = new float[99];
		    Location.distanceBetween(startLati, startLongi, goalLati, goalLongi, resultArray);
		    return resultArray[0];
	}
} 