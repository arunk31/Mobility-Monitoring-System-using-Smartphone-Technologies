<html lang="en">
<?php
if (version_compare(PHP_VERSION, '5.3.7', '<')) {
    exit('Sorry, this script does not run on a PHP version smaller than 5.3.7 !');
} else if (version_compare(PHP_VERSION, '5.5.0', '<')) {
    require_once('libraries/password_compatibility_library.php');
}

require_once('config/config.php');

require_once('translations/en.php');

require_once('libraries/PHPMailer.php');

require_once('classes/Login.php');

?>
<head>
<title>Mobility Monitoring System</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/grid.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.4.2.min.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_italic_400-Myriad_Pro_italic_600.font.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/jquery.faded.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<!--[if lt IE 7]>
<script type="text/javascript" src="js/ie_png.js"></script>
<script type="text/javascript">ie_png.fix('.png, .logo, .extra-banner');</script>
<![endif]-->
<!--[if lt IE 9]><script type="text/javascript" src="js/html5.js"></script><![endif]-->
</head>
<body>
<?php 
$login = new Login();
if ($login->isUserLoggedIn() == true) {
?>
<header>
  <div class="container_16">
    <div class="logo">
      <h1><a href="#"><strong>Mobility</strong> Monitor</a></h1>
    </div>
    <nav>
      <ul>
        <li><a href="index.php">Recent</a></li>
        <li><a href="indivi.php">Individual</a></li>
		<li><a href="misspath.php">Missed Path</a></li>
        <li><a href="alert.php">Alert</a></li>
        <li><a href="about.php">About</a></li>
	<li><a href="index.php?logout">Logout</a></li>
      </ul>
    </nav>
</header>
<section id="content">
  <div class="container_16">
    <div class="clearfix">
      <section id="mainContent" class="grid_10">
        <article>
			<?php
			$con = mysql_connect("mysql.2freehosting.com","u934952747_arun","masters9500");
			if(!con){
				die("Cant connect to database" . mysql_error());
			}
			// echo " Connection to DB Success <br /><br />";
			mysql_select_db("u934952747_arun",$con);
			// echo "Data Recorded in DB ordered by recent data <br />";
			$sql = "SELECT * FROM locdata ORDER BY slno DESC LIMIT 0, 50";
			$myData = mysql_query($sql, $con);
			echo "<br /><table border=1>
			<tr>
			<th>Time</th>
			<th>User</th>
			<th>Latitude</th>
			<th>Longitude</th>
			<th>Location</th>
			</tr>";
			while($record = mysql_fetch_array($myData)){
				
				echo "<tr><td> " . $record['time'] . "</td>";
				echo "<td> " . $record['email'] . "</td>";
				echo "<td> " . $record['latitude'] . "</td>";
				echo "<td> " . $record['longitude'] . "</td> ";
				echo "<td> <a href=\"javascript:window.open('loc.php?lat=" . $record['latitude'] ."&lng=" . $record['longitude'] . "','Located At','width=500,height=380')\" > LocateMe! </a></td></tr>";
			}
			echo "</table><br />";
			mysql_close($con); 
		?>
          </article>
</section>
		  	<aside class="grid_6">
        <div class="prefix_1">
          <article>
            <div class="box">
              <h2>Paste Values from table aside to locate</h2>
			  <form name="locate" action="map.php" method="post">
				<lable> Latitude Value: </lable> <input name="lat" type="text" /> <br />
				<lable> Longitude Value: </lable> <input name="lng" type="text" /> <br />
				<input type="submit" value="Locate Me!"  />
			</form>
            </div>
          </article>
        </div>
      </aside>
   </div>
  </div>
</section>
<?php
} else {
?>
<header>
  <div class="container_16">
    <div class="logo">
      <h1><a href="#"><strong>Mobility</strong> Monitor</a></h1>
    </div>
<nav>
      <ul>
        <li><a href="about.php">About</a></li>
      </ul>
    </nav>
</header>
<section id="content">
  <div class="container_16">
    <div class="clearfix">
      <section id="mainContent" class="grid_10">
        <article>
<img src="world.jpg" height=309px width=500px />
  </article>
        </section>
		  	<aside class="grid_6">
        <div class="prefix_1">
          <article>
            <div class="box">
        	  <?php   
    			include("views/not_logged_in.php");
		?>
            </div>
          </article>
        </div>
      </aside>
   </div>
  </div>
</section>
<?php
}
?>
<footer>
  <div class="footerlink">
    <p class="lf">Copyright &copy; 2014 <a href="#">Mobility Monitoring System</a> - All Rights Reserved</p>
    
    <div style="clear:both;"></div>
  </div>
</footer>
<script type="text/javascript">
$(function () {
    //accordion
    $(".accordion dt").toggle(function () {
        $(this).next().slideDown();
    }, function () {
        $(this).next().slideUp();
    });
})
</script>
<script type="text/javascript"> Cufon.now(); </script>
</body>
</html>