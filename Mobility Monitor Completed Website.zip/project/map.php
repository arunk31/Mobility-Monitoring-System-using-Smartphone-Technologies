<?php
    $lat = $_POST['lat'];
	$lng = $_POST['lng'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Mobility Monitoring System : Location</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/grid.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.4.2.min.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_italic_400-Myriad_Pro_italic_600.font.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/jquery.faded.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<!--[if lt IE 7]>
<script type="text/javascript" src="js/ie_png.js"></script>
<script type="text/javascript">ie_png.fix('.png, .logo, .extra-banner');</script>
<![endif]-->
<!--[if lt IE 9]><script type="text/javascript" src="js/html5.js"></script><![endif]-->
<script
src="http://maps.googleapis.com/maps/api/js?key=AIzaSyAQyckVrVRMIsmkGDT_HKxaPVYvefCFpRo&sensor=false">
</script>
<script>
      var lat = "<?php echo $lat ?>";
       var lng="<?php echo $lng ?>";
var myCenter=new google.maps.LatLng(lat,lng);
function initialize()
{
var mapProp = {
  center:myCenter,
  zoom:8,
  mapTypeId:google.maps.MapTypeId.ROADMAP
  };

  
var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);

var marker=new google.maps.Marker({
  position:myCenter,
  animation:google.maps.Animation.BOUNCE
  });

  google.maps.event.addListener(marker,'click',function() {
  map.setZoom(14);
  map.setCenter(marker.getPosition());
  });
//  var myCity = new google.maps.Circle({
//  center:amsterdam,
//  radius:20000,
//  strokeColor:"#0000FF",
//  strokeOpacity:0.8,
//  strokeWeight:2,
//  fillColor:"#0000FF",
//  fillOpacity:0.4
//  });
// myCity.setMap(map);
 -->
  
marker.setMap(map);
}
google.maps.event.addDomListener(window, 'load', initialize);
    </script>
  </head>
  <body>
<header>
  <div class="container_16">
    <div class="logo">
      <h1><a href="#"><strong>Mobility</strong> Monitor</a></h1>
    </div>
    <nav>
      <ul>
        <li><a href="index.php">Recent</a></li>
        <li><a href="indivi.php">Individual</a></li>
		<li><a href="misspath.php">Missed Path</a></li>
        <li><a href="alert.php">Alert</a></li>
        <li><a href="about.php">About</a></li>
		<li><a href="index.php?logout">Logout</a></li>
        </ul>
    </nav>
</header>
<section id="content">
  <div class="container_16">
    <div class="clearfix">
      <section id="mainContent" class="grid_10">
        <article>
    <div id="googleMap" style="width:500px;height:380px;"></div>
   </article>
</section>
<aside class="grid_6">
        <div class="prefix_1">
          <article>
            <div class="box">
              <h2>Paste Values from table aside to locate</h2>
			  <form name="locate" action="map.php" method="post">
				<lable> Latitude Value: </lable> <input name="lat" type="text" /> <br />
				<lable> Longitude Value: </lable> <input name="lng" type="text" /> <br />
				<input type="submit" value="Locate Me!"  />
			</form>
            </div>
			
</article>
        </div>
      </aside>
    </div>
  </div>
</section>
<footer>
  <div class="footerlink">
    <p class="lf">Copyright &copy; 2014 <a href="#">Mobility Monitoring System</a> - All Rights Reserved</p>
    
    <div style="clear:both;"></div>
  </div>
</footer>
<script type="text/javascript">
$(function () {
    //accordion
    $(".accordion dt").toggle(function () {
        $(this).next().slideDown();
    }, function () {
        $(this).next().slideUp();
    });
})
</script>
<script type="text/javascript"> Cufon.now(); </script>

</body>
</html>