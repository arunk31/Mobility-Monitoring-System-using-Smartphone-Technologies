<!DOCTYPE html>
<html lang="en">
<?php
if (version_compare(PHP_VERSION, '5.3.7', '<')) {
    exit('Sorry, this script does not run on a PHP version smaller than 5.3.7 !');
} else if (version_compare(PHP_VERSION, '5.5.0', '<')) {
    require_once('libraries/password_compatibility_library.php');
}

require_once('config/config.php');

require_once('translations/en.php');

require_once('libraries/PHPMailer.php');

require_once('classes/Login.php');

?>
<head>
<title>Mobility Monitoring System : About</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/grid.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.4.2.min.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_italic_400-Myriad_Pro_italic_600.font.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/jquery.faded.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<!--[if lt IE 7]>
<script type="text/javascript" src="js/ie_png.js"></script>
<script type="text/javascript">ie_png.fix('.png, .logo, .extra-banner');</script>
<![endif]-->
<!--[if lt IE 9]><script type="text/javascript" src="js/html5.js"></script><![endif]-->
</head>
<body>
<?php 
$login = new Login();
if ($login->isUserLoggedIn() == true) {
?>
<header>
  <div class="container_16">
    <div class="logo">
      <h1><a href="#"><strong>Mobility</strong> Monitor</a></h1>
    </div>
    <nav>
      <ul>
        <li><a href="index.php">Recent</a></li>
        <li><a href="indivi.php">Individual</a></li>
		<li><a href="misspath.php">Missed Path</a></li>
        <li><a href="alert.php">Alert</a></li>
        <li><a href="about.php">About</a></li>
		<li><a href="index.php?logout">Logout</a></li>
        </ul>
    </nav>
</header>
<section id="content">
  <div class="container_16">
    <div class="clearfix">
      <section id="mainContent" class="grid_10">
        <article>
			<h2>MOBILITY MONITORING SYSTEM USING SMARTPHONE TECHNOLOGY</h2><br /><br />
<h3>ABSTRACT:</h3><br /><p>
Introduction  of  smartphones  redefined  the  usage  of mobile  phones  in  the  communication  world. Today, smartphones are equipped with numerous sensors and sophisticated features which helps the mobile phone users to keep in touch with the modern world. GPS are one such thing that are usually found embedded in these phones, there is already a notable rise in applications that take advantage of the offered geographical positioning functionality. Security threat can occur anywhere, so we propose a mobile application that would performs localization of the client in an efficient manner using GPS, shows the client�s navigation in a personalized monitoring system and stores it in a remote database for future references for personal safety. It is also possible for it to alerts them when the limit of the geo-fence is crossed via SMS or Android notification technology. This application can be particularly important for monitoring kids, vehicle, trawling, etc.

	</p>
			
			
			
          </article>
        </article>
    </div>
  </div>
</section>
<?php
} else {
?>
<header>
  <div class="container_16">
    <div class="logo">
      <h1><a href="#"><strong>Mobility</strong> Monitor</a></h1>
    </div>
	<nav>
      <ul>
        <li><a href="about.php">About</a></li>
		<li><a href="index.php">Login/SignUp</a></li>
      </ul>
    </nav>
</header>
<section id="content">
  <div class="container_16">
    <div class="clearfix">
      <section id="mainContent" class="grid_10">
        <article>
			<h2>MOBILITY MONITORING SYSTEM USING SMARTPHONE TECHNOLOGY</h2><br /><br />
<h3>ABSTRACT:</h3><br /><p>
Introduction  of  smartphones  redefined  the  usage  of mobile  phones  in  the  communication  world. Today, smartphones are equipped with numerous sensors and sophisticated features which helps the mobile phone users to keep in touch with the modern world. GPS are one such thing that are usually found embedded in these phones, there is already a notable rise in applications that take advantage of the offered geographical positioning functionality. Security threat can occur anywhere, so we propose a mobile application that would performs localization of the client in an efficient manner using GPS, shows the client�s navigation in a personalized monitoring system and stores it in a remote database for future references for personal safety. It is also possible for it to alerts them when the limit of the geo-fence is crossed via SMS or Android notification technology. This application can be particularly important for monitoring kids, vehicle, trawling, etc.

	</p>
			
			
			
          </article>
        </article>
    </div>
  </div>
</section>
<?php
}
?>
<footer>
  <div class="footerlink">
    <p class="lf">Copyright &copy; 2014 <a href="#">Mobility Monitoring System</a> - All Rights Reserved</p>
    
    <div style="clear:both;"></div>
  </div>
</footer>
<script type="text/javascript">
$(function () {
    //accordion
    $(".accordion dt").toggle(function () {
        $(this).next().slideDown();
    }, function () {
        $(this).next().slideUp();
    });
})
</script>
<script type="text/javascript"> Cufon.now(); </script>
<!-- END PAGE SOURCE -->
</body>
</html>
