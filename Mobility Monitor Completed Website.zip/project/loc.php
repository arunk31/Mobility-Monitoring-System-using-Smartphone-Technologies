<?php
    $lat = $_GET['lat'];
	$lng = $_GET['lng'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Mobility Monitoring System : Location</title>
<meta charset="utf-8">
<script
src="http://maps.googleapis.com/maps/api/js?key=AIzaSyAQyckVrVRMIsmkGDT_HKxaPVYvefCFpRo&sensor=false">
</script>
<script>
      var lat = "<?php echo $lat ?>";
       var lng="<?php echo $lng ?>";
var myCenter=new google.maps.LatLng(lat,lng);
function initialize()
{
var mapProp = {
  center:myCenter,
  zoom:8,
  mapTypeId:google.maps.MapTypeId.ROADMAP
  };

  
var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);

var marker=new google.maps.Marker({
  position:myCenter,
  animation:google.maps.Animation.BOUNCE
  });

  google.maps.event.addListener(marker,'click',function() {
  map.setZoom(14);
  map.setCenter(marker.getPosition());
  });
//  var myCity = new google.maps.Circle({
//  center:amsterdam,
//  radius:20000,
//  strokeColor:"#0000FF",
//  strokeOpacity:0.8,
//  strokeWeight:2,
//  fillColor:"#0000FF",
//  fillOpacity:0.4
//  });
// myCity.setMap(map);
 -->
  
marker.setMap(map);
}
google.maps.event.addDomListener(window, 'load', initialize);
    </script>
  </head>
  <body>

    <div id="googleMap" style="width:500px;height:380px;"></div>
   

</body>
</html>