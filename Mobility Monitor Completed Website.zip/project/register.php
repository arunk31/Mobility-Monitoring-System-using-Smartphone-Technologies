<html lang="en">
<?php

if (version_compare(PHP_VERSION, '5.3.7', '<')) {
    exit('Sorry, this script does not run on a PHP version smaller than 5.3.7 !');
} else if (version_compare(PHP_VERSION, '5.5.0', '<')) {

    require_once('libraries/password_compatibility_library.php');
}

require_once('config/config.php');

require_once('translations/en.php');

require_once('libraries/PHPMailer.php');

require_once('classes/Registration.php');
?>
<head>
<title>Mobility Monitoring System : Register</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/grid.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.4.2.min.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_italic_400-Myriad_Pro_italic_600.font.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/jquery.faded.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<!--[if lt IE 7]>
<script type="text/javascript" src="js/ie_png.js"></script>
<script type="text/javascript">ie_png.fix('.png, .logo, .extra-banner');</script>
<![endif]-->
<!--[if lt IE 9]><script type="text/javascript" src="js/html5.js"></script><![endif]-->
</head>
<body>
<header>
  <div class="container_16">
    <div class="logo">
      <h1><a href="#"><strong>Mobility</strong> Monitor</a></h1>
    </div>
<nav>
<ul>
<li><a href="about.php">About</a></li>
<li><a href="index.php">LogIn/SignUp</a></li>
</ul>
</nav>
</header>
<section id="content">
  <div class="container_16">
    <div class="clearfix">
      <section id="mainContent" class="grid_10">
        <article>

 </article>
       </section>
		  	<aside class="grid_6">
        <div class="prefix_1">
          <article>
            <div class="box">
<?php

$registration = new Registration();

include("views/register.php");

?>
</div>
          </article>
        </div>
      </aside>
   </div>
  </div>
</section>
<footer>
  <div class="footerlink">
    <p class="lf">Copyright &copy; 2014 <a href="#">Mobility Monitoring System</a> - All Rights Reserved</p>
    
    <div style="clear:both;"></div>
  </div>
</footer>
<script type="text/javascript">
$(function () {
    //accordion
    $(".accordion dt").toggle(function () {
        $(this).next().slideDown();
    }, function () {
        $(this).next().slideUp();
    });
})
</script>
<script type="text/javascript"> Cufon.now(); </script>
<!-- END PAGE SOURCE -->
</body>
</html>