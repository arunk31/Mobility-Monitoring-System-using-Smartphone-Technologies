/** Automatically generated file. DO NOT MODIFY */
package cms.cse.finalyear.project.mobimoni;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}