<?php
/**
 * Database config variables
 */
define("DB_HOST", "mysql.2freehosting.com");
define("DB_USER", "u934952747_arun");
define("DB_PASSWORD", "masters9500");
define("DB_DATABASE", "u934952747_arun");

/*
 * Google API Key
 */
define("GOOGLE_API_KEY", "AIzaSyAQyckVrVRMIsmkGDT_HKxaPVYvefCFpRo"); // Place your Google API Key
?>